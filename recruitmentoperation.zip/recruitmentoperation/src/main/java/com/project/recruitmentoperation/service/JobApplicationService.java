package com.project.recruitmentoperation.service;

import com.project.recruitmentoperation.entity.JobProcessDetails;

public interface JobApplicationService {
	
	public void	save (JobProcessDetails upload);
	 

}
