package com.project.recruitmentoperation.dao;

import com.project.recruitmentoperation.entity.JobProcessDetails;

public interface JobApplicationDao {
	
	  public void save(JobProcessDetails uploadFile) ;

}
